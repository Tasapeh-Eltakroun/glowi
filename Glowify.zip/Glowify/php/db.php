<?php
$conn = new mysqli("sqlXXX.infinityfree.com","username","password","dbname");

if($conn->connect_error){
    die("Connection Failed");
}
?>