<?php
include "db.php";

// قراءة البيانات من fetch (JSON)
$data = json_decode(file_get_contents("php://input"), true);

// تأكد إن البيانات موجودة
if(!$data){
    echo "No Data ❌";
    exit;
}

$total = $data['total'] ?? 0;
$items = $data['items'] ?? [];

$user_id = 1;

// حفظ الأوردر
$sql = "INSERT INTO orders (user_id, total) VALUES ($user_id, $total)";
if(!$conn->query($sql)){
    die("Error in Order: " . $conn->error);
}

$order_id = $conn->insert_id;

// حفظ المنتجات
foreach($items as $item){
    $pid = $item['id'] ?? 1;
    $qty = $item['quantity'] ?? 1;

    $sql2 = "INSERT INTO order_items (order_id, product_id, quantity)
             VALUES ($order_id, $pid, $qty)";

    if(!$conn->query($sql2)){
        die("Error in Items: " . $conn->error);
    }
}

echo "Order Saved ✅";
?>